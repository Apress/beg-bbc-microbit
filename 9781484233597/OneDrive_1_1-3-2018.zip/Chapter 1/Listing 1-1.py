from microbit import *

display.scroll("Hello World!", delay=150, loop=True)
