from microbit import *

display.scroll("Hello from Mu REPL", delay=150, loop=True)
