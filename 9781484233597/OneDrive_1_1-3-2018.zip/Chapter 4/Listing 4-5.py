from microbit import *

i2c.write(0x1d, bytes([0x2a, 1]), repeat=False)

while True:
    Byte = i2c.read(0x1d, 2)[1]
    print(Byte)
    sleep(100)
