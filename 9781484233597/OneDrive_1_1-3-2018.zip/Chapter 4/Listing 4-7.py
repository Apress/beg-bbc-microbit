from microbit import *

uart.init(baudrate=19200, bits=8, parity=None, stop=1, tx=pin0)

while True:
    if button_a.was_pressed():
        uart.write('Button A was pressed\x0A\x0A')
    elif button_b.was_pressed():
        uart.write('Button B was pressed\x0A\x0A')
    sleep(100)
