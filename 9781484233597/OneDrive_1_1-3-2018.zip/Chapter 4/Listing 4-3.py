from microbit import *

while True:
    pin1.write_analog(pin0.read_analog())
    sleep(100)
