from microbit import *

while True:
    if pin0.read_digital():
        pin1.write_digital(1)
    else:
        pin1.write_digital(0)
