from microbit import *

last_gesture = ""

while True:
    current_gesture = accelerometer.current_gesture()
    sleep(100)
    if current_gesture is not last_gesture:
        last_gesture = current_gesture
        print('>{g:s}<'.format(g=current_gesture))
