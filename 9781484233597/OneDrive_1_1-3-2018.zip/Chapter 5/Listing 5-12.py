import math
from microbit import *

compass.calibrate()

while True:
    x = compass.get_x()
    y = compass.get_y()
    angle = math.atan2(y, x) * 180/math.pi
    print("x", x, " y", y)
    print("Direction: ", angle)
    sleep(500)
