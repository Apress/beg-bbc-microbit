from microbit import *

compass.calibrate()

while True:
    heading = compass.heading()
    print("heading: ", heading)
    sleep(500)
