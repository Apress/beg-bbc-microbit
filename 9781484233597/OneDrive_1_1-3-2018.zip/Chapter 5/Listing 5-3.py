from microbit import *

while True:
    val = accelerometer.get_x()
    if val > 0:
        display.show(Image.ARROW_W)
    elif val < 0:
        display.show(Image.ARROW_E)
    else:
        display.show(Image.YES)
