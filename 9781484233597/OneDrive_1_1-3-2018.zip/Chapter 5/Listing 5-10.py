from microbit import *

gestList = []

while True:
    gestures = accelerometer.get_gestures()
    print(len(gestures))

    if len(gestures) == 1:
        gestList.append(gestures[0])
        sleep(500)

    print("History: "+str(gestList))
