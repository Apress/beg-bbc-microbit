from microbit import *

while True:
    result = accelerometer.get_values()
    print("Values:", result)
    sleep(500)
