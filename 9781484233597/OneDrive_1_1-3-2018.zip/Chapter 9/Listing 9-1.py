from microbit import *

while True:
    if button_a.is_pressed():
        pin1.write_digital(1)
    else:
        pin1.write_digital(0)

    input = pin2.read_digital()
    if (input == 1):
        display.show(Image.HAPPY)
    else:
        display.clear()
