from microbit import *

buffer = ''

while True:
    # Sending
    if button_a.was_pressed():
        pin1.write_digital(1)
    else:
        pin1.write_digital(0)

    # Receiving
    if (pin2.read_digital() == 1):
        buffer += 'x '

    if button_b.was_pressed():
        display.scroll(buffer)
        buffer = ''
    sleep(100)
