from microbit import *
import radio

radio.on()  # turns the radio on
radio.config(power=7)

while True:
    if(button_a.was_pressed()):  # to turn the remote LED on
        radio.send("H")  # sends letter H to receiver
    elif(button_b.was_pressed()):  # to turn the remote LED off
        radio.send("L")  # sends letter L to receiver
    sleep(100)
