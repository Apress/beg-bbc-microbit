from microbit import *
import radio

radio.on()  # turns the radio on
radio.config(power=7)

pin0.write_digital(0)  # turns the LED off on startup

while True:
    message = radio.receive()  # read incoming message
    if (message == "H"):  # compare incoming message
        pin0.write_digital(1)  # turns the LED on
    if (message == "L"):
        pin0.write_digital(0)  # turns the LED off
