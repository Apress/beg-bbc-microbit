from microbit import *
import radio

radio.on()  # turns the radio on
radio.config(power=7)

while True:
    message = radio.receive()
    if (message == "F"):  # FORWARD
        pin8.write_digital(1)  # motor 1
        pin12.write_digital(0)  # motor 1
        pin0.write_digital(1)  # motor 2
        pin16.write_digital(0)  # motor 2
    if (message == "B"):  # BACKWARD
        pin8.write_digital(0)  # motor 1
        pin12.write_digital(1)  # motor 1
        pin0.write_digital(0)  # motor 2
        pin16.write_digital(1)  # motor 2
    if (message == "S"):  # BRAKE
        pin8.write_digital(1)  # motor 1
        pin12.write_digital(1)  # motor 1
        pin0.write_digital(1)  # motor 2
        pin16.write_digital(1)  # motor 2
    if (message == "C"):  # COAST
        pin8.write_digital(0)  # motor 1
        pin12.write_digital(0)  # motor 1
        pin0.write_digital(0)  # motor 2
        pin16.write_digital(0)  # motor 2
