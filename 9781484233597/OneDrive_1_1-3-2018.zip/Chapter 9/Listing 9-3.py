from microbit import *
import radio

radio.on()  # turns the radio on
sleep(5000)
radio.off()  # turns the radio off
