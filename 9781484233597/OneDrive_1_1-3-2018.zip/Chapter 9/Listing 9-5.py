from microbit import *
import radio

radio.on()

while True:
    incoming = radio.receive()
    if incoming is not None:
        display.show(incoming)  # print(incoming)
    sleep(500)
