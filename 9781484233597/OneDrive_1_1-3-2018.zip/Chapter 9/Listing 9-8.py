from microbit import *
import radio

radio.on()  # turns the radio on
radio.config(power=7)

while True:
    if(button_a.is_pressed()):
        radio.send("F")  # FORWARD
    elif(button_b.is_pressed()):
        radio.send("B")  # BACKWARD
    elif(button_a.is_pressed() and button_b.is_pressed()):
        radio.send("S")  # BRAKE
    else:
        radio.send("C")  # COAST
    sleep(100)
