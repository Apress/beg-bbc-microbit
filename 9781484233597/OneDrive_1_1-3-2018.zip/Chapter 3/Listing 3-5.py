from microbit import *

while True:
    sleep(10000)
    display.scroll(str(button_a.get_presses()))
