with open('foo.txt', 'w') as foo:
    foo.write("foo")
with open('bar.txt', 'w') as bar:
    bar.write("bar")
with open('baz.py', 'w') as baz:
    baz.write("a=5")
with open('qux.py', 'w') as qux:
    qux.write("b=7")
