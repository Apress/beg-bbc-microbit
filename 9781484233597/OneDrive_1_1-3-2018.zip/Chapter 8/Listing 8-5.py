with open('greeting.py', 'w') as myFile:
    myFile.write("def showGreeting():\n")
    myFile.write("  print('Hello Friend!')")
