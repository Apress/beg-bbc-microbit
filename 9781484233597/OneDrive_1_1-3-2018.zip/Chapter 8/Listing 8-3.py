with open('foo.txt', 'w') as myFile:
    myFile.write("This is the first line\n")
    myFile.write("This is the second line")
