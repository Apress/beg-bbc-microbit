with open('foo.txt', 'w') as myFile:
    myFile.write("This is the first line")
