with open('foo.txt') as myFile:
    print(myFile.read())
