with open('foo.py', 'w') as myFile:
    myFile.write("i=10\n")
    myFile.write("print('-------------')\n")
    myFile.write("print(i)\n")
    myFile.write("print('-------------')")
