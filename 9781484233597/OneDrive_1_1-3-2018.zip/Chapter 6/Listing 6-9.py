from microbit import *
import music

while True:
    if button_a.is_pressed():
        music.play('Ab')  # Play a 'A-flat'
        music.play('C#')  # Play a 'C-sharp'
