from microbit import *
import music

tune = ["C", "D", "E", "F", "G"]
music.play(tune)
