from microbit import *
import music

music.play(music.BIRTHDAY, loop=True)
