from microbit import *
import music

music.set_tempo()  # set the bpm to 120 and ticks to 4
music.play('C4:3')
