from microbit import *
import music

music.pitch(440, -1)
