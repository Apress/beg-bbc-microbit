from microbit import *
import music

tune = ["C", "D", "E", "R", "F", "G"]
music.play(tune)
