from microbit import *
import music

while True:
    if button_a.is_pressed():
        music.play('C3')  # Play a 'C3'
