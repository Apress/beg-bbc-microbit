from microbit import *
import music

music.play(music.BIRTHDAY, pin=pin1, loop=True)
