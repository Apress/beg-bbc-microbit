from microbit import *
import music

music.set_tempo(bpm=180)  # set the bpm to 180
music.play('C4:3')
