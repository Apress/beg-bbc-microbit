from microbit import *
import music

while True:
    if button_a.is_pressed():  # Play a 'C'
        music.play('C')
