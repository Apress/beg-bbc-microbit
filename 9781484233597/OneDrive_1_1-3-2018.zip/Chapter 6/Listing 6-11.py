from microbit import *
import music

music.set_tempo(ticks=8)  # set ticks to 8
music.play('C4:3')
