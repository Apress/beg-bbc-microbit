from microbit import *
import music

music.set_tempo(bpm=180, ticks=8)  # set the bpm to 180 and ticks to 8
tempo = music.get_tempo()
print("Current Tempo: ", tempo)
