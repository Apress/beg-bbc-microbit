from microbit import *
import music

while True:
    if button_a.is_pressed():
        music.play('C')  # Play a 'C'
        music.play('D')  # Play a 'D'
        music.play('E')  # Play a 'E'
        music.play('F')  # Play a 'F'
        music.play('G')  # Play a 'G'
        music.play('A')  # Play a 'A'
        music.play('B')  # Play a 'B'
