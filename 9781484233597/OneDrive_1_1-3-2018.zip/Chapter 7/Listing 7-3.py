from microbit import *
import speech

speech.say("Hello, World")  # default pitch is 64
sleep(1000)

speech.say("Hello, World", pitch=10)  # impractical
sleep(1000)

speech.say("Hello, World", pitch=25)  # very high
sleep(1000)

speech.say("Hello, World", pitch=35)  # high
sleep(1000)

speech.say("Hello, World", pitch=45)  # high normal
sleep(1000)

speech.say("Hello, World", pitch=60)  # normal
sleep(1000)

speech.say("Hello, World", pitch=75)  # low normal
sleep(1000)

speech.say("Hello, World", pitch=85)  # low
sleep(1000)

speech.say("Hello, World", pitch=170)  # very low
