from microbit import *
import speech

speech.pronounce("/HEHLOW")  # "Hello"
