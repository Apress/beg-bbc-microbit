from microbit import *
import speech

speech.pronounce("/HEH3LOW")  # "Hello"
