from microbit import *
import speech

speech.sing("#115 /H AE P IY B ER TH D EY T UW Y UW", speed=100)
speech.sing("#115 /H AE P IY B ER TH D EY T UW Y UW", speed=100)
speech.sing("#115 /H AE P IY B ER TH D EY D IH R M AY K R OW B IH T", speed=100)
speech.sing("#115 /H AE P IY B ER TH D EY T UW Y UW", speed=100)
