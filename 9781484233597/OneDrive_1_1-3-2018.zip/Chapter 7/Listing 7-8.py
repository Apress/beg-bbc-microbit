from microbit import *
import speech

speech.say("I am a baker bot", speed=120, pitch=100, throat=100, mouth=200)
