from microbit import *
import speech

speech.say("Hello, World")
