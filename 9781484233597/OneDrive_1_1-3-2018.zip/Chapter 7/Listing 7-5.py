from microbit import *
import speech

speech.say("Hello, World")  # default speed is 72
sleep(1000)

speech.say("Hello, World", speed=10)  # impractical
sleep(1000)

speech.say("Hello, World", speed=30)  # very fast
sleep(1000)

speech.say("Hello, World", speed=50)  # fast
sleep(1000)

speech.say("Hello, World", speed=65)  # fast conversational
sleep(1000)

speech.say("Hello, World", speed=73)  # normal conversational
sleep(1000)

speech.say("Hello, World", speed=83)  # narrative
sleep(1000)

speech.say("Hello, World", speed=95)  # slow
sleep(1000)

speech.say("Hello, World", speed=175)  # very slow
sleep(1000)
