from microbit import *
import speech

print(speech.translate("Hello"))
