from microbit import *

# first set the brightness level to 5
display.set_pixel(3, 2, 5)
# then get the current brightness level
pixel_brightness = display.get_pixel(3, 2)
display.scroll("brightness is: "+str(pixel_brightness))
