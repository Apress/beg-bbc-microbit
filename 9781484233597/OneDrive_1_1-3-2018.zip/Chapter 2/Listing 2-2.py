from microbit import *

display.set_pixel(3, 2, 5)  # set the brightness level to 5
