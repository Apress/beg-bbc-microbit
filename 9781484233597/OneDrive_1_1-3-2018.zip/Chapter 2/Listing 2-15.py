from microbit import *

spooky = [Image.GHOST, Image.SWORD, Image.SKULL]
display.show(spooky, loop=True, delay=1000)
