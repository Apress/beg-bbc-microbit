from microbit import *

while True:
    display.set_pixel(3, 2, 9)  # turn on the LED
    sleep(1000)  # wait for 1 second
    display.set_pixel(3, 2, 0)  # turn off the LED
    sleep(1000)  # wait for 1 second
