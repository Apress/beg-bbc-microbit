from microbit import *

FISH = Image("00700:"
             "09905:"
             "99955:"
             "09905:"
             "00700")

display.show(FISH)
