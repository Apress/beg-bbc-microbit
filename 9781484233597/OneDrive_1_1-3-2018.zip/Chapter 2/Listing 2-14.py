from microbit import *

for x in range(0, 12):
    display.show(Image.ALL_CLOCKS[x])
    sleep(100)
