from microbit import *

display.show(Image.ALL_CLOCKS[6])  # index 6 for CLOCK6
