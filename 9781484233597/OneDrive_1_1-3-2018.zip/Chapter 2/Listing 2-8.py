from microbit import *

FISH = Image("00900:"
             "09909:"
             "99999:"
             "09909:"
             "00900")

display.show(FISH)
