from microbit import *

FISH_1 = Image("00700:"
               "09905:"
               "99955:"
               "09905:"
               "00700")

FISH_2 = Image("07000:"
               "99050:"
               "99550:"
               "99050:"
               "07000")

FISH_3 = Image("70000:"
               "90500:"
               "95500:"
               "90500:"
               "70000")

FISH_4 = Image("00000:"
               "05000:"
               "55000:"
               "05000:"
               "00000")

FISH_5 = Image("00000:"
               "50000:"
               "50000:"
               "50000:"
               "00000")

FISH_6 = Image("00000:"
               "00000:"
               "00000:"
               "00000:"
               "00000")

ALL_FISH = [FISH_1, FISH_2, FISH_3, FISH_4, FISH_5, FISH_6]
display.show(ALL_FISH, loop=True, delay=250)
